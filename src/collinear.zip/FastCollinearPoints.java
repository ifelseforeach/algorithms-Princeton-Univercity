
public class FastCollinearPoints {
    public FastCollinearPoints(Point[] points) { // finds all line segments
                                                 // containing 4 or more points
        // TODO

    }

    public int numberOfSegments() { // the number of line segments
        // TODO
        return 0;

    }

    public LineSegment[] segments() { // the line segments
        
            return new LineSegment[0];
     
    }
}
